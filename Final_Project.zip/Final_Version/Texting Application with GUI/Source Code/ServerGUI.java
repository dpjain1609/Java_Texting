import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;

public class ServerGUI extends JFrame implements ActionListener{

    public static void main(String[] args) {
        new ServerGUI();
    }

    ServerSocket serverSocket;
    Thread server;
    
    public ServerGUI(){
        try {            
            setLayout(null);
            this.serverSocket = new ServerSocket(5000);
            this.setTitle("Server");
            this.setSize(400, 200);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.setVisible(true);
            
            JButton startServer = new JButton("Start Server");
            startServer.setBounds(0, 0, 150, 100);
            startServer.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e){
                    server = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            System.out.println("Starting server");
                            startServer();
                        }
                    });

                    server.start();
                }
            });
            add(startServer);

            JButton stopServer = new JButton("Stop Server");
            stopServer.setBounds(150, 0, 150, 100);
            stopServer.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e){
                    server.interrupt();
                    closeServer();
                    System.out.println("Server closed");
                    System.exit(0);
                }
            });
            add(stopServer);
        

        } catch (Exception e) {

        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
    }

    public void startServer(){
        while(!this.serverSocket.isClosed()){

            try {
                Socket socket = this.serverSocket.accept();
                Handler handler = new Handler(socket);

                Thread thread = new Thread(handler);
                thread.start();

            } catch (Exception e) {
                closeServer();
            }
        }
    }

    public void closeServer(){
        try {
            if(this.serverSocket != null){
                this.serverSocket.close();
            }
        } catch (Exception e) {

        }
    }
}
