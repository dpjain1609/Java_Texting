import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class ClientGUI extends JFrame implements ActionListener{

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter username for the group chat: ");
        String username = scanner.nextLine();
        ClientGUI client = new ClientGUI(username);
        client.listenForMessage();
        scanner.close();
    }

    private String username;

    private final int HEIGHT;
    private final int WIDTH;
    
    private JPanel header;
    private JButton leaveServer;
    private JPanel chatPanel;
    private JTextField messageField;
    private JButton send;
    private Color themeColor = new Color(89, 89, 89);
    
    private Box verticalBox = Box.createVerticalBox();
    
    private Socket socket;
    private ObjectOutputStream objectOutputStream;
    private ObjectInputStream objectInputStream;

    public ClientGUI(String clientUsername){
        
        this.username = clientUsername;

        //header
        header = new JPanel();
        header.setLayout(null);
        header.setBackground(themeColor);
        header.setBounds(0, 0, 600, 50);
        add(header);
        
        //client's username
        JLabel username = new JLabel(clientUsername);
        username.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        username.setForeground(Color.WHITE);
        username.setBounds(30, 5, 200, 40);
        header.add(username);
        
        //connected message
        JLabel connectedToServer = new JLabel("Connected");
        connectedToServer.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        connectedToServer.setForeground(Color.GREEN);
        connectedToServer.setBounds(250, 5, 100, 40);
        header.add(connectedToServer);
        
        //leave server button
        leaveServer = new JButton();
        leaveServer.setBackground(new Color(255, 0, 0));
        leaveServer.setText("Leave Server");
        leaveServer.setBounds(460, 5, 120, 40);
        leaveServer.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e){
                setVisible(false);
                System.exit(0);
            }
        });
        header.add(leaveServer);
        
        //chat
        chatPanel = new JPanel();
        chatPanel.setBounds(0, 50, 600, 400);
        add(chatPanel);
        
        //footer -> must have a text area and a few buttons
        
        //chat box
        messageField = new JTextField();
        messageField.setBounds(0, 450, 500, 120);
        connectedToServer.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        add(messageField);

        //send button
        send = new JButton("Send");
        send.setBounds(500, 450, 100, 120);
        send.addActionListener(this);
        add(send);
        
        messageField.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e){
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    sendMessage();
                }
            }
        });
        
        //main frame
        setLayout(null); 
        this.HEIGHT = 608;
        this.WIDTH = 615;
        this.setTitle("Texting Application");
        this.setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setSize(WIDTH, HEIGHT);
        this.setResizable(false);
        getContentPane().setBackground(new Color(94, 95, 99));
        
        //connecting to the host
        //initializing object input and object streams
        //sending an initial message
        try {
            this.socket = new Socket("localhost", 5000);
            this.objectOutputStream = new ObjectOutputStream(this.socket.getOutputStream());
            this.objectInputStream = new ObjectInputStream(this.socket.getInputStream());
            Message usernameObject = new Message(false, this.username, "");
            this.objectOutputStream.writeObject(usernameObject); 

        } catch (Exception e) {

        }


    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        sendMessage();
    }

    public void sendMessage(){
        String plainTextmessage = messageField.getText();
    
        try{
            
            JLabel sendMessage = new JLabel(plainTextmessage);
            sendMessage.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
            sendMessage.setForeground(Color.WHITE);
            sendMessage.setBackground(themeColor);
            sendMessage.setOpaque(true);

            JPanel sendMessagePanel = new JPanel();
            sendMessagePanel.add(sendMessage);
            
            chatPanel.setLayout(new BorderLayout());
            
            JPanel rightPanel = new JPanel(new BorderLayout());
            rightPanel.add(sendMessagePanel, BorderLayout.LINE_END);
            verticalBox.add(rightPanel);
            verticalBox.add(Box.createVerticalStrut(10));
            chatPanel.add(verticalBox, BorderLayout.PAGE_START);
            
            repaint();
            invalidate();
            validate();
            
            messageField.setText("");
            
            Message messageToClient = new Message(false, this.username, plainTextmessage);
            objectOutputStream.writeObject(messageToClient);
            objectOutputStream.flush();
        
        } catch(Exception e){

        }
    }

    public void listenForMessage(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                Message messageFromGroupChat;

                while(socket.isConnected()){
                    try {
                        messageFromGroupChat = (Message)objectInputStream.readObject();
                        int shift = messageFromGroupChat.getShiftValue();
                        String textMessage = decrypt(messageFromGroupChat.getMessageBody(), shift);

                        JLabel messageReceived = new JLabel(messageFromGroupChat.getSender() + ": " +textMessage);
                        messageReceived.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
                        messageReceived.setForeground(Color.WHITE);
                        messageReceived.setBackground(themeColor);
                        messageReceived.setOpaque(true);

                        JPanel sendMessagePanel = new JPanel();
                        sendMessagePanel.add(messageReceived);
                        
                        chatPanel.setLayout(new BorderLayout());

                        JPanel leftPanel = new JPanel(new BorderLayout());
                        leftPanel.add(sendMessagePanel, BorderLayout.LINE_START);
                        verticalBox.add(leftPanel);
                        verticalBox.add(Box.createVerticalStrut(10));
                        chatPanel.add(verticalBox, BorderLayout.PAGE_START);

                        repaint();
                        invalidate();
                        validate();
    
                    } catch (Exception e) {
                        break;
                   }
                }
                
            }
        }).start();
    }

    // Decrypt a message using Caesar cipher
    private String decrypt(String encryptedMessage, int shift) {
        StringBuilder decryptedMessage = new StringBuilder();

        for (char c : encryptedMessage.toCharArray()) {
            // Decryption logic for each character
            if (Character.isLetter(c)) {
                char shiftedChar = (char) (c - shift);
                if ((Character.isLowerCase(c) && shiftedChar < 'a') ||
                    (Character.isUpperCase(c) && shiftedChar < 'A')) {
                    shiftedChar += 26; // Wrap around the alphabet
                }
                decryptedMessage.append(shiftedChar);
            } else {
                decryptedMessage.append(c); // Keep non-letter characters unchanged
            }

        }

        return decryptedMessage.toString();
    }

}