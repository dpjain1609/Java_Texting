Steps to run the program:
Compile java files: javac *.java
On one terminal, run the server: java Server
Run clients on other terminals: java Client

To send a message to a particular client: clientUsername;message
To send a message to multiple user: username1;username2;username3;message
To send a message to everyone: all;message
To quit: quit
